#pragma once

void open_door(int target_floor, int current_floor);

void close_door();