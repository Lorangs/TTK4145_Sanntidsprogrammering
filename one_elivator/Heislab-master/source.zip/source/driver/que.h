#pragma once

void check_if_buttons_pressed(void);

void print_floorpanel(void);

void print_elevatorpanel(void);