#include <assert.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <pthread.h>
//#include <windows.h>

#include "elevio.h"
#include "con_load.h"
#include "door.h"


int door_open = 0;

void open_door(int target_floor, int current_floor){
    if (target_floor == current_floor){
        door_open = 1;
        elevio_doorOpenLamp(1); 
    }
}

void close_door(){
    int obstruction = elevio_obstruction();

    while(obstruction == 1){
        elevio_doorOpenLamp(1);
    }
    
    sleep(30); //venter i 3 sek før døren lukkes
    
    door_open = 0;
    elevio_doorOpenLamp(0);    
}