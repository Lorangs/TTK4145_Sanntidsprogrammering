#pragma once

void floor_state_and_light();  
