#include "elevio.h"
#include "que.h"


int floorpanel[6][2]={{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1}};  //matrix med [etasje nommer, opp=1 ned =0],[e,o],...

int elevatorpanel[4]={-1,-1,-1,-1};  //matrix med [etasje nommer]


void addfloor(int level, int direktion){
    int already_exsist=0;
    for (int i=0; i < 6; i++){
        if (floorpanel[i][0]==level && floorpanel[i][1]==direktion){
            already_exsist=1;
        }
    }
    if (!already_exsist){
        for (int i=0; i < 6; i++){
            if (floorpanel[i][0]==-1){
                floorpanel[i][0]=level;
                floorpanel[i][1]=direktion;
                break;
            }
        }
    }
}

void addelevator(int level){
    int already_exsist=0;
    for (int i=0; i < 4; i++){
        if (elevatorpanel[i]==level){
            already_exsist=1;
        }
    }
    if (!already_exsist){
        for (int i=0; i < 4; i++){
            if (elevatorpanel[i]==-1){
                elevatorpanel[i]=level;
                break;
            }
        }
    }
}

void check_if_buttons_pressed(void){
    for (int i=0; i < 4; i++){
        if (elevio_callButton(i,BUTTON_HALL_DOWN)){
            addfloor(i,0);
        }
        if (elevio_callButton(i,BUTTON_HALL_UP)){
            addfloor(i,1);
        }
        if (elevio_callButton(i,BUTTON_CAB)){
            addelevator(i);
        }
    }
}

void print_floorpanel(void){
    for (int i=0; i < 6; i++){
        printf("\n    %d",floorpanel[i][0]);
        printf(",   %d",floorpanel[i][1]);
    }
}

void print_elevatorpanel(void){
    for (int i=0; i < 4; i++){
        printf("    %d",elevatorpanel[i]);
    }
}

void elevator_order_executed(level){
    for (int i=0; i < 4; i++){
        if (elevatorpanel[i]==level){
            elevatorpanel[i]=-1;
        }
    }
    for (int i=0; i < 3; i++){
        if (elevatorpanel[i]==-1){
            elevatorpanel[i]=elevatorpanel[i+1];
            break;
        }
    }
}

void floor_order_executed(level){
    
}
