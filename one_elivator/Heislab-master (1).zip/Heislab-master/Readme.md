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

´´´
git add .
git commit -m "melding"
git push
´´´