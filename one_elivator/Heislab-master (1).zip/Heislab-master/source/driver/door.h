#pragma once

void open_door();

void open_door_after_stop();

int close_door();