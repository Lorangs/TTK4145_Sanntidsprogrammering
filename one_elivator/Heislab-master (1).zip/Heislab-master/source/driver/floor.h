#pragma once

int floor_state_and_light();  
