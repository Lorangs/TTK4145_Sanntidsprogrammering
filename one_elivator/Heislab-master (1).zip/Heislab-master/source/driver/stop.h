#pragma once

void stop();